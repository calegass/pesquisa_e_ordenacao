#ifndef ARVORE_MULTIPLA_H
#define ARVORE_MULTIPLA_H
#include "listadupla.h"

struct nom
{
    int info;
    int nro_filhos;
    int infectada;
    struct nom *pai;
    Listad *filhos;
};

typedef struct nom Nom;
void insere(Nom *tree, int info, int pai);

Nom *localiza_pai(Nom *raiz, int pai);
Nom *cria_nom(int info);
Nom *mostra(Nom *raiz);
#endif
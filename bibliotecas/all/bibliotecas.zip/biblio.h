#ifndef BIBLIO_H
#define BIBLIO_H

#include <stdlib.h>
#include <stdio.h>

int scanf_return ();

#endif
#include "bibliovetores.h"

void inicializarVetor(float vetor[], int tamanhoVetor)
{
    int i=0;
    for(i=0; i<tamanhoVetor; i++)
        vetor[i]=0;
}

void armazenarVetor(float vetor[], int tamanhoVetor)
{
    int i=0;
    for(i=0; i<tamanhoVetor; i++)
    {
        printf("Informe a nota %d: ", i+1);
        scanf("%f", &vetor[i]);
    }
}

void mostrarVetor(float vetor[], int tamanhoVetor)
{
    int i=0;
    for(i=0; i<tamanhoVetor; i++)
        printf("Vetor %d = %.2f\n", i+1, vetor[i]);
}

float* adVetor(int nro_elementos) // alocação dinâmica de vetor
{
    float *vet;
    vet = (float *) malloc(nro_elementos*sizeof(float));
    return vet;
}

float* verificar50(float vetor[], int tamanhoVetor, int *tam2)
{
    float *vet50;
    int i, nro_maiorque50=0;

    for(i=0; i<tamanhoVetor; i++)
    {
        if(vetor[i]>50)
            nro_maiorque50++;
    }

    vet50 = (float *) malloc(nro_maiorque50*sizeof(float));

    nro_maiorque50=0;

    for(i=0; i<tamanhoVetor; i++)
    {
        if(vetor[i]>50)
        {
            vet50[nro_maiorque50]=vetor[i];
            nro_maiorque50++;
        }
    }

    *tam2=nro_maiorque50;

    return vet50;
}
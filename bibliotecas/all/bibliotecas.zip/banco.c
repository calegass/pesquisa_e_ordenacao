#include "banco.h"

Conta zerar_num ()
{
    Conta dados;
    dados.num = 0;
    return dados;
}

int menu ()
{
    int i;
    printf ("Escolha o que deseja fazer:\n1 - Analisar as contas do banco;\n2 - Criar uma nova conta;\n3 - Efetuar uma transferencia;\n: ");
    scanf ("%d", &i);
    return i;
}

Conta receber_dados ()
{
    Conta dados;

    printf ("Digite o numero da conta: ");
    scanf ("%d", &dados.num);

    printf ("Dados pessoais:\n");
    fflush (stdin);
    printf ("Nome: ");
    gets (dados.correntista.nome);
    fflush (stdin);
    printf ("Sobrenome: ");
    gets (dados.correntista.sobrenome);
    printf ("Idade: ");
    scanf ("%d", &dados.correntista.idade);
    fflush (stdin);
    printf ("CPF: ");
    gets (dados.correntista.cpf);
    fflush (stdin);
    printf ("Estado: ");
    gets (dados.correntista.end.estado);
    fflush (stdin);
    printf ("CEP: ");
    gets (dados.correntista.end.cep);
    fflush (stdin);
    printf ("Cidade: ");
    gets (dados.correntista.end.cidade);
    fflush (stdin);
    printf ("Bairro: ");
    gets (dados.correntista.end.bairro);
    fflush (stdin);
    printf ("Logradouro: ");
    gets (dados.correntista.end.logradouro);
    printf ("Tipo de moradia: [1 - CASA, 2 - PREDIO]: ");
    scanf ("%d", &dados.correntista.end.tipo_moradia);
    printf ("Numero (externo, caso seja predio): ");
    scanf ("%d", &dados.correntista.end.num);
    if (dados.correntista.end.tipo_moradia == 2){
        fflush (stdin);
        printf ("Numero interno do predio: ");
        scanf ("%d", &dados.correntista.end.num_ap);
    }
    printf ("Digite o seu saldo: ");
    scanf ("%f", &dados.saldo);
    printf ("\n\n");

    return dados;
}

void mostrar_dados (Conta dados)
{
    printf ("Numero da conta: %d\n", dados.num);
    printf ("Nome: %s\n", dados.correntista.nome);
    printf ("Sobrenome: %s\n", dados.correntista.sobrenome);
    printf ("Idade: %d\n", dados.correntista.idade);
    printf ("CPF: %s\n", dados.correntista.cpf);
    printf ("CEP: %s\n", dados.correntista.end.cep);
    printf ("Estado: %s\n", dados.correntista.end.estado);
    printf ("Cidade: %s\n", dados.correntista.end.cidade);
    printf ("Bairro: %s\n", dados.correntista.end.bairro);
    printf ("Logradouro: %s\n", dados.correntista.end.logradouro);
    printf ("Tipo de moradia: %d\n", dados.correntista.end.tipo_moradia);
    printf ("Numero: %d\n", dados.correntista.end.num);
    printf ("Numero do predio: %d\n", dados.correntista.end.num_ap);
    printf ("Saldo: %.2f\n\n", dados.saldo);
    printf ("\n\n");
}

int transferir_saldo (Conta *c1, Conta *c2, int valor)
{
    int resposta = 0;

    if (c1->saldo >= valor){
        c1->saldo = c1->saldo - valor;
        c2->saldo = c2->saldo + valor;
        resposta = 1;
    }
    return resposta;
}
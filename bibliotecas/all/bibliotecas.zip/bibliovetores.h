#ifndef BIBLIOVETORES_H_INCLUDED
#define BIBLIOVETORES_H_INCLUDED
#define TAM 100

#include <stdlib.h>
#include <stdio.h>

void inicializarVetor(float vetor[], int tamanhoVetor);
void armazenarVetor(float vetor[], int tamanhoVetor);
void mostrarVetor(float vetor[], int tamanhoVetor);
float* adVetor(int nro_elementos);
float* verificar50(float vetor[], int tamanhoVetor, int *tam2);

#endif
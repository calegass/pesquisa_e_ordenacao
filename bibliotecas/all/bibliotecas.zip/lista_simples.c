#include "lista_simples.h"

Node *criar_node (int info)
{
    Node* new = NULL;
    new = (Node*) malloc (sizeof (Node));

    new->prox = NULL;
    new->info = info;

    return new;
}

Node *inserir_inicio (Node* end, int info)
{
	Node* new;

	if (end == NULL)
	{
		end = criar_node (info);
	}
	else
	{
		new = criar_node (info);
		new->prox = end;
		end = new;
	}
	return end;
}

Node *inserir_final (Node* end, int info)
{
    Node* new = criar_node (info);
    Node* aux = end;

    if (end == NULL)
        end = new;

    else
    {
        while (aux->prox != NULL)
            aux = aux->prox;
        aux->prox = new;
    }
    return end;
}

Node *buscar_valor (Node* end, int info)
{
    Node *ilist = end;

    while (ilist->info != info && ilist->prox != NULL)
    {
        ilist = ilist->prox;
    }

    return ilist;
}

void inserir_escolha (Node* end, int info)
{
    Node *new = NULL, *auxiliar = end, *proximo = NULL; 

    new = criar_node (info);

    proximo = end->prox;
    end->prox = new;
    new->prox = proximo;
}

void mostrar_lista (Node* end)
{
    Node *aux = end;

    while (aux != NULL)
    {
        printf ("%d ", aux->info);
        aux = aux->prox; 
    }
    printf ("\n");
}

Node* remover_elemento (Node** end_end, int info)
{
    Node *aux, *anterior = NULL, *resposta = NULL;
    if (*end_end != NULL)
    {
        aux = *end_end;
        while (aux != NULL && aux->info != info)
        {
            anterior = aux;
            aux = aux->prox;
        }
        if (aux != NULL)
        {
            if(*end_end != aux)
                anterior->prox = aux->prox;
            else
                *end_end = aux->prox;
        }
        resposta = aux;
    }
    return resposta;
}

Node *primeiro_elemento (Node **inicial)
{
    Node *auxiliar = *inicial;

    auxiliar = auxiliar->prox;
    *inicial = auxiliar;

    return auxiliar;
}

Node *ultimo_elemento (Node *inicial)
{
    Node *auxiliar = inicial, *anterior;

    while (auxiliar->prox != NULL)
    {
        anterior = auxiliar;
        auxiliar = auxiliar->prox;
    }

    anterior->prox = NULL;

    return auxiliar;
}

int conteudo_primeiro (Node **inicial)
{
    Node *auxiliar = *inicial, *anterior = *inicial;

    auxiliar = auxiliar->prox;
    *inicial = auxiliar;

    return anterior->info;
}

int conteudo_ultimo (Node *inicial)
{
    Node *auxiliar = inicial, *anterior;

    while (auxiliar->prox != NULL)
    {
        anterior = auxiliar;
        auxiliar = auxiliar->prox;
    }

    anterior->prox = NULL;

    return auxiliar->info;
}

void desalocar_lista (Node *end)
{
    Node *auxiliar = end;

    while (auxiliar != NULL)
    {
        end = end->prox;
        free(auxiliar);
        auxiliar = end;
    }
}

Node *maximo (Node *inicial)
{
    Node *aux = criar_node (0), *copia = inicial;

    aux->info = copia->info;

    while (copia->prox != NULL)
    {
        copia = copia->prox;
        if (copia->info > aux->info)
        {
            aux->info = copia->info;
        }
    }
    return aux;
}

Node *minimo (Node *inicial)
{
    Node *aux = criar_node (0), *copia = inicial;

    aux->info = copia->info;

    while (copia->prox != NULL)
    {
        copia = copia->prox;
        if (copia->info < aux->info)
        {
            aux->info = copia->info;
        }
    }
    return aux;
}

Node *reverse (Node *inicial)
{
    Node *aux = inicial, *aux2 = inicial, *new = NULL;
    int i = 0, tam = 1;

    while (aux2->prox != NULL)
    {
        tam++;
        aux2 = aux2->prox;
    }
    for (i = 0; i < tam; i++)
    {
        new = inserir_inicio (new, aux->info);
        aux = aux->prox;
    }
    return new;
}

Node *copy (Node *inicial)
{
    Node *new = inicial;

    return new;
}

Node *copy_2 (Node *inicial)
{
    Node *aux = inicial, *aux2 = inicial, *new = NULL;
    int i = 0, tam = 1;

    while (aux2->prox != NULL)
    {
        tam++;
        aux2 = aux2->prox;
    }
    for (i = 0; i < tam; i++)
    {
        new = inserir_final (new, aux->info);
        aux = aux->prox;
    }
    return new;
}

Node *sort (Node *inicial)
{
    Node *auxiliar = inicial, *aux2 = inicial, *aux3 = NULL, *min = NULL;
    int i, tam = 1;
    
    while (aux2->prox != NULL)
    {
        tam++;
        aux2 = aux2->prox;
    }

    for (i = 0; i < tam; i++)
    {
        min = minimo (auxiliar);
        remover_elemento (&auxiliar, min->info);
        aux3 = inserir_final (aux3, min->info);
    }

    return aux3;
}

int tamanho (Node *inicial)
{
    Node *aux2 = inicial;
    int tam = 1;
    
    while (aux2->prox != NULL)
    {
        tam++;
        aux2 = aux2->prox;
    }
    return tam;
}

void trocar (Node *new)
{
    Node *inicial2 = new, *inf_request = NULL;
    int content, value;

    scanf ("%d", &content);
    inf_request = buscar_valor (inicial2, content);
    
    scanf ("%d", &value);
    inserir_escolha (inf_request, value);

    remover_elemento (&inicial2, content);
}

Node *inserir_esquerda (Node *new)
{
    Node *inicial2 = new, *aux = NULL;
    int content, value, antigo;

    scanf ("%d", &content);
    scanf ("%d", &value);

    aux = criar_node (value);

    while (inicial2->prox != NULL)
    {
        if (inicial2->info == content)
        {
            aux->prox = inicial2->prox;
            inicial2->prox = aux;
        }
        inicial2 = inicial2->prox;
    }

    return inicial2;
}

Node *inserir_direita (Node *new)
{
    Node *inicial2 = new, *inicial3 = new, *aux = NULL, *aux1 = NULL;
    int content, value, antigo;

    scanf ("%d", &content);
    scanf ("%d", &value);

    aux1 = criar_node (value);

    while (inicial2->prox != NULL)
    {
        if (inicial2->prox->info == content)
        {
            aux = inicial2;
        }
        inicial2 = inicial2->prox;
    }
    
    while (inicial3 != aux)
    {
        aux1->prox = inicial3->prox;
        inicial3 = aux1;
    }
    

    return inicial2;
}

void mostrar_lista_concatenada (Node *c1, Node *c2)
{
    Node *aux1 = c1, *aux2 = c2, *aux11 = NULL, *aux22 = NULL;

    while (aux1->prox != NULL)
    {
        aux1 = aux1->prox; 
    }
    aux1->prox = aux2;

    c1 = sort (c1);

    aux11 = c1;

    while (aux11 != NULL)
    {
        if (aux11->prox != NULL && aux11->prox->info == aux11->info)
        {
            printf ("%d ", aux11->info);
        }
        aux11 = aux11->prox;
        
    }
    printf ("\n");

    while (c1 != NULL)
    {
        if (c1->prox != NULL && c1->prox->info != c1->info)
        {
            printf ("%d ", c1->info);
        }
        
        else if (c1->prox == NULL)
        {
            printf ("%d ", c1->info);
        }
        c1 = c1->prox;
        
    }
    printf ("\n");
}
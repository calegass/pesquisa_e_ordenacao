#include "biblio.h"

int scanf_return ()
{
    int i;
    scanf ("%d", &i);
    return i;
}
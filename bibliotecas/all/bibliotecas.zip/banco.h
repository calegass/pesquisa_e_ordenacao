#ifndef BANCO_H
#define BANCO_H

#include <stdio.h>
#include <stdlib.h>

struct endereco
{
    char cep[20];
    char estado[20];
    char cidade[100];
    char bairro[100];
    char logradouro[100];
    char tipo_moradia;
    int num;
    int num_ap;
};

typedef struct endereco Endereco;

struct cliente
{
    char nome[20];
    char sobrenome[100];
    int idade;
    char cpf[20];
    Endereco end;
};

typedef struct cliente Cliente;

struct conta
{
    int num;
    Cliente correntista;
    float saldo;
};

typedef struct conta Conta;

Conta zerar_num ();

int menu ();

Conta receber_dados ();

void mostrar_dados (Conta dados);

int transferir_saldo (Conta *c1, Conta *c2, int valor);

#endif
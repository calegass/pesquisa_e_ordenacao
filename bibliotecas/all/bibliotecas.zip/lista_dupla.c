#include "lista_dupla.h"

//função aloca um espaço na memória para a Lista_d: 
Lista_d *criar_Lista_d ()
{
    Lista_d *L = (Lista_d*) malloc (sizeof (Lista_d));
    
    L->ini = L->fim = NULL;
    return L;
}

//aloca um espaço para o nó
Noded *criar_noded ()
{
    Noded* new = NULL;
    new = (Noded*) malloc (sizeof (Noded));

    new->ant = NULL;
    new->prox = NULL;

    return new;
}

//insere um valor no início da lista
void inserir_iniciod (Lista_d *Laux, int valor)
{    
    Noded *aux = criar_noded ();
    
    if (Laux->ini == NULL)
        Laux->fim = aux;
    
    aux->prox = Laux->ini;
    Laux->ini = aux;
    aux->info = valor;

    if (aux->prox != NULL)
        aux->prox->ant = aux;
    else
        aux->ant = NULL;
}

//insere um valor no final da lista
void inserir_finald (Lista_d *Laux, int valor)
{
    Noded *aux = criar_noded ();

    if (Laux->fim == NULL)
        Laux->ini = aux;

    aux->ant = Laux->fim;
    Laux->fim = aux;
    aux->info = valor;

    if (aux->ant != NULL)
        aux->ant->prox = aux;
    else
        aux->prox = NULL;

}

//imprime a lista no terminal
void mostrar_Lista_d (Lista_d *L)
{
    Noded *no = L->ini;
    
    while (no != L->fim)
    {
        printf ("%d ", no->info);
        no = no->prox;
    }
    printf ("%d \n", no->info);
}

//retorna o nó com o valor máximo
Noded *maximod (Lista_d *Laux)
{
    Noded* aux = Laux->ini, *retorno = aux;
    int max = aux->info;

    while (aux->prox != NULL)
    {
        if (aux->info > max)
        {
            max = aux->info;
            retorno = aux;
        }
        aux = aux->prox;
    }
    if (aux->info > max)
    {
        max = aux->info;
        retorno = aux;
    }
    return retorno;
}

//retorna o nó com o valor mínimo
Noded *minimod (Lista_d *Laux)
{
    Noded* aux = Laux->ini, *retorno = aux;
    int min = aux->info;

    while (aux->prox != NULL)
    {
        if (aux->info < min)
        {
            min = aux->info;
            retorno = aux;
        }
        aux = aux->prox;
    }
    if (aux->info < min)
    {
        min = aux->info;
        retorno = aux;
    }
    return retorno;
}

//reverte a lista 
Lista_d *reversed (Lista_d *Laux)
{
    Lista_d *Laux_2 = criar_Lista_d ();
    Noded *aux_1 = NULL, *aux_2 = NULL;

    aux_2 = Laux->ini;

    while (aux_2->prox != NULL)
    {
        inserir_iniciod (Laux_2, aux_2->info);
        aux_2 = aux_2->prox;
    }
    inserir_iniciod (Laux_2, aux_2->info);
    return Laux_2;
}

void reversed_interno (Lista_d *Laux)
{
    Lista_d *Laux_2 = criar_Lista_d ();
    Noded *aux_1 = NULL, *aux_2 = NULL;

    aux_2 = Laux->ini;

    while (aux_2->prox != NULL)
    {
        inserir_iniciod (Laux_2, aux_2->info);
        aux_2 = aux_2->prox;
    }
    inserir_iniciod (Laux_2, aux_2->info);
    Laux = Laux_2;
}

Lista_d *remover_elementod (Lista_d* end_end, int info)
{
    Lista_d *aux = end_end, *aux_return;

    aux_return->ini = end_end->ini;
    aux_return->fim = end_end->fim;

    if (aux->ini == aux->fim && aux->ini->info == info)
    {
        aux->ini = aux_return->ini = NULL;
        aux->fim = aux_return->fim = NULL;
    }
    else if (aux->ini == aux->fim && aux->ini->info != info)
    {
        aux->ini = aux_return->ini;
        aux->fim = aux_return->fim;
    }
    else if (aux->ini->info == info)
    {
        aux->ini = aux->ini->prox;
        aux->ini->ant = NULL;
        aux_return->ini = aux->ini;
    }
    else if (aux->fim->info == info)
    {
        aux->fim = aux->fim->ant;
        aux->fim->prox = NULL;
        aux_return->fim = aux->fim;
    }
    else 
    {
        while (aux->ini != NULL)
        {
            if (aux->ini->info == info)
            {
                aux->ini->ant->prox = aux->ini->prox;
                aux->ini->prox->ant = aux->ini->ant;
            }

            aux->ini = aux->ini->prox;
        }
    }
    return aux_return;
}
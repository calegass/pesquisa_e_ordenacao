#ifndef LISTA_DUPLA_H
#define LISTA_DUPLA_H

#include <stdio.h>
#include <stdlib.h>

struct noded
{
    int info;
    struct noded *prox;
    struct noded *ant;
};
typedef struct noded Noded;

struct lista_d
{
    Noded *ini;
    Noded *fim;
};
typedef struct lista_d Lista_d;

Lista_d *criar_Lista_d ();
Noded *criar_noded ();
void inserir_iniciod (Lista_d *Laux, int valor);
void inserir_finald (Lista_d *Laux, int valor);
void mostrar_Lista_d (Lista_d *L);
Noded *maximod (Lista_d *Laux);
Noded *minimod (Lista_d *Laux);
Lista_d *reversed (Lista_d *Laux);
void reversed_interno (Lista_d *Laux);
Lista_d *remover_elementod (Lista_d* end_end, int info);

#endif
#ifndef LISTA_SIMPLES_H
#define LISTA_SIMPLES_H

#include <stdlib.h>
#include <stdio.h>

struct node
{
    int info;
    struct node *prox;
};

typedef struct node Node;

Node *criar_node (int info);
Node *inserir_inicio (Node* end, int info);
Node *inserir_final (Node* end, int info);
Node *buscar_valor (Node* end, int info);
void inserir_escolha (Node* end, int info);
void mostrar_lista (Node* end);
Node *remover_elemento (Node** end_end, int info);
void *remover_inicio (Node** end_end);
Node *primeiro_elemento (Node **inicial);
Node *ultimo_elemento (Node *inicial);
int conteudo_primeiro (Node **inicial);
int conteudo_ultimo (Node *inicial);
void desalocar_lista (Node *end);
Node *maximo (Node *inicial);
Node *minimo (Node *inicial);
Node *reverse (Node *inicial);
Node *copy (Node *inicial);
Node *copy_2 (Node *inicial);
Node *sort (Node *inicial);
int tamanho (Node *inicial);
void trocar (Node *new);
Node *inserir_esquerda (Node *new);
Node *inserir_direita (Node *new);
void mostrar_lista_concatenada (Node *c1, Node *c2);

#endif